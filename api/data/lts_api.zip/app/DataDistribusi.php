<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataDistribusi extends Model
{
  protected $table="distribusi_panen";
  protected $primaryKey ="id";
  public $timestamp = false;
  protected $guarded=['id'];
}
